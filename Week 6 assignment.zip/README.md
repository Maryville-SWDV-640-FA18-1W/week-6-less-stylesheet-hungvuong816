# Less-Stylesheet
Add specific color scheme styling into your existing HTML layout utilizing a separate LESS stylesheet. 

Include color variables, nested styling, and mixins into your LESS stylesheet that the various HTML elements in your page will use. 

Submit a zip file of your entire package and include the LESS file.
